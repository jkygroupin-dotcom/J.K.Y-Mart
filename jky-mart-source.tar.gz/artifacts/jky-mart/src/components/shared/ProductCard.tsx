import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Heart, ShoppingCart, Star, Check, Zap } from "lucide-react";
import { Product } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  className?: string;
  size?: "sm" | "md" | "lg";
  horizontal?: boolean;
}

function StarRating({ rating, count }: { rating: number; count: number }) {
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded text-white text-[10px] font-bold"
        style={{ background: "#388E3C" }}>
        <span>{rating.toFixed(1)}</span>
        <Star className="w-2.5 h-2.5 fill-white" />
      </div>
      <span className="text-[10px]" style={{ color: "#8D9096" }}>({count.toLocaleString()})</span>
    </div>
  );
}

export function ProductCard({ product, className, size = "md", horizontal = false }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(product.id);
  const [added, setAdded] = useState(false);
  const savings = product.originalPrice - product.price;

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  if (horizontal) {
    return (
      <motion.div whileHover={{ scale: 1.01 }} transition={{ duration: 0.15 }}
        className={cn("flex gap-3 rounded-xl p-3 lift", className)}
        style={{ background: "#13141B", border: "1px solid rgba(255,255,255,0.07)" }}
        data-testid={`product-card-${product.id}`}>
        <Link href={`/product/${product.id}`} className="shrink-0">
          <div className="w-24 h-24 rounded-lg overflow-hidden shine" style={{ background: "#1C1E27" }}>
            <img src={product.images[0]} alt={product.name} className="img-zoom w-full h-full object-cover" loading="lazy" />
          </div>
        </Link>
        <div className="flex-1 min-w-0 py-0.5">
          <Link href={`/product/${product.id}`}>
            <div className="text-sm font-semibold line-clamp-2 leading-snug mb-1.5 hover:text-orange-400 transition-colors" style={{ color: "#E2E8F0" }}>
              {product.name}
            </div>
          </Link>
          <StarRating rating={product.rating} count={product.reviewCount} />
          <div className="flex items-baseline gap-1.5 mt-1.5">
            <span className="text-base font-black" style={{ color: "#CC0000" }}>₹{product.price.toLocaleString()}</span>
            {product.originalPrice > product.price && (
              <span className="text-xs line-through" style={{ color: "#8D9096" }}>₹{product.originalPrice.toLocaleString()}</span>
            )}
            {product.discountPercentage > 0 && (
              <span className="text-xs font-bold" style={{ color: "#00A650" }}>-{product.discountPercentage}%</span>
            )}
          </div>
          <button onClick={handleAdd} className="mt-2 px-3 py-1.5 rounded text-xs font-bold text-white transition-all active:scale-95 flex items-center gap-1.5"
            style={{ background: added ? "#00A650" : "#FF6900" }}>
            {added ? <><Check className="w-3 h-3" />Added</> : <><ShoppingCart className="w-3 h-3" />Add to Cart</>}
          </button>
        </div>
        <button onClick={(e) => { e.preventDefault(); toggleWishlist(product.id); }}
          className="shrink-0 w-8 h-8 flex items-center justify-center rounded-full self-start transition-all"
          style={{ color: inWishlist ? "#CC0000" : "#5C5F69" }}>
          <Heart className={cn("w-4 h-4", inWishlist ? "fill-red-600" : "")} />
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.18 }}
      className={cn("flex flex-col rounded-xl overflow-hidden group lift", className)}
      style={{ background: "#13141B", border: "1px solid rgba(255,255,255,0.07)" }}
      data-testid={`product-card-${product.id}`}
    >
      {/* Image */}
      <Link href={`/product/${product.id}`} className="block relative overflow-hidden">
        <div className={cn("w-full overflow-hidden shine", size === "sm" ? "aspect-square" : "aspect-[4/3]")}
          style={{ background: "#1C1E27" }}>
          <img src={product.images[0]} alt={product.name}
            className="img-zoom w-full h-full object-cover" loading="lazy" />
        </div>

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
          {product.discountPercentage >= 20 && (
            <span className="text-[10px] font-black px-1.5 py-0.5 rounded text-white"
              style={{ background: "#CC0000" }}>
              -{product.discountPercentage}%
            </span>
          )}
          {product.discountPercentage >= 40 && (
            <span className="text-[9px] font-black px-1.5 py-0.5 rounded flex items-center gap-0.5"
              style={{ background: "#FF6900", color: "#fff" }}>
              <Zap className="w-2.5 h-2.5" />Deal
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button onClick={e => { e.preventDefault(); toggleWishlist(product.id); }}
          className={cn("absolute top-2 right-2 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all",
            inWishlist ? "opacity-100" : "opacity-0 group-hover:opacity-100")}
          style={{ background: "rgba(255,255,255,0.9)", boxShadow: "0 2px 8px rgba(0,0,0,0.3)" }}
          data-testid={`btn-wishlist-${product.id}`}>
          <Heart className={cn("w-4 h-4", inWishlist ? "fill-red-600 text-red-600" : "text-gray-600")} />
        </button>
      </Link>

      {/* Info */}
      <div className="p-3 flex flex-col flex-1">
        {/* Brand */}
        <div className="text-[10px] font-semibold uppercase tracking-wider mb-1" style={{ color: "#1A73E8" }}>
          {product.brand}
        </div>

        {/* Name */}
        <Link href={`/product/${product.id}`}>
          <div className="text-xs font-medium line-clamp-2 leading-snug mb-2 hover:text-orange-400 transition-colors"
            style={{ color: "#C8CAD0", minHeight: "30px" }}>
            {product.name}
          </div>
        </Link>

        {/* Rating */}
        <div className="mb-2">
          <StarRating rating={product.rating} count={product.reviewCount} />
        </div>

        {/* Price */}
        <div className="mb-2">
          <div className="flex items-baseline gap-1.5 flex-wrap">
            <span className="text-lg font-black" style={{ color: "#CC0000" }}>
              ₹{product.price.toLocaleString()}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs line-through" style={{ color: "#8D9096" }}>
                ₹{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>
          {savings > 0 && (
            <div className="text-[11px] font-semibold" style={{ color: "#00A650" }}>
              Save ₹{savings.toLocaleString()} ({product.discountPercentage}% off)
            </div>
          )}
        </div>

        {/* Free delivery */}
        {product.price > 499 && (
          <div className="text-[10px] mb-2.5" style={{ color: "#00A650" }}>
            ✓ FREE Delivery
          </div>
        )}

        {/* Add to cart */}
        <button onClick={handleAdd}
          className="mt-auto w-full py-2 rounded-lg text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-1.5"
          style={{
            background: added
              ? "linear-gradient(180deg, #4CAF50, #388E3C)"
              : "linear-gradient(180deg, #F0A30A, #FF6900)",
            color: added ? "#fff" : "#111",
            border: added ? "1px solid #388E3C" : "1px solid #C45500",
            boxShadow: "0 2px 0 rgba(0,0,0,0.3)",
          }}
          data-testid={`btn-add-cart-${product.id}`}>
          {added
            ? <><Check className="w-3.5 h-3.5" /> Added to Cart</>
            : <><ShoppingCart className="w-3.5 h-3.5" /> Add to Cart</>}
        </button>
      </div>
    </motion.div>
  );
}
