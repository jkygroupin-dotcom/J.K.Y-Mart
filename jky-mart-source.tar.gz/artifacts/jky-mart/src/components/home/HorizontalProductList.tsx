import { Link } from "wouter";
import { ProductCard } from "@/components/shared/ProductCard";
import { Product } from "@/data/products";
import { ArrowRight } from "lucide-react";

interface HorizontalProductListProps {
  title: string;
  subtitle?: string;
  products: Product[];
  viewAllLink?: string;
  cardSize?: "sm" | "md" | "lg";
}

export function HorizontalProductList({
  title,
  subtitle,
  products,
  viewAllLink = "/categories",
  cardSize = "md",
}: HorizontalProductListProps) {
  if (!products.length) return null;

  const cardWidth = cardSize === "sm" ? 130 : cardSize === "lg" ? 210 : 165;

  return (
    <section className="py-5">
      {/* Section header */}
      <div className="flex items-end justify-between mb-4 px-0.5">
        <div>
          {subtitle && (
            <div className="text-[10px] font-bold uppercase tracking-widest text-[#C9A84C] mb-1">{subtitle}</div>
          )}
          <h2 className="text-lg font-bold text-white/90 leading-none tracking-tight">{title}</h2>
        </div>
        <Link
          href={viewAllLink}
          className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-widest text-white/35 hover:text-[#C9A84C] transition-colors group"
        >
          All
          <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      </div>

      {/* Horizontal scroll */}
      <div className="overflow-x-auto no-scrollbar -mx-4 px-4">
        <div className="flex gap-3.5" style={{ width: "max-content", paddingRight: "16px" }}>
          {products.map((product) => (
            <div key={product.id} style={{ width: `${cardWidth}px` }} className="shrink-0">
              <ProductCard product={product} size={cardSize} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
