import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

const banners = [
  {
    id: 1,
    tag: "🔥 Mega Sale",
    headline: "Up to 70% OFF",
    sub: "Fashion, Electronics, Home & More",
    cta: "Shop Now",
    bg: "linear-gradient(135deg, #0D1117 0%, #1A1A2E 40%, #231838 100%)",
    accent: "#FF6900",
    img: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&q=80",
    badge: "LIMITED TIME",
  },
  {
    id: 2,
    tag: "⚡ Flash Deal",
    headline: "Flat ₹2000 OFF",
    sub: "On Premium Electronics & Gadgets",
    cta: "Grab Deal",
    bg: "linear-gradient(135deg, #0D1521 0%, #0A2240 40%, #0D3060 100%)",
    accent: "#1A73E8",
    img: "https://images.unsplash.com/photo-1593359677879-a4bb92f4a833?w=800&q=80",
    badge: "TODAY ONLY",
  },
  {
    id: 3,
    tag: "💚 Weekend Offer",
    headline: "Buy 2 Get 1 FREE",
    sub: "On Beauty, Skincare & Personal Care",
    cta: "Explore Deals",
    bg: "linear-gradient(135deg, #071A12 0%, #0D3320 40%, #0F4228 100%)",
    accent: "#00A650",
    img: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&q=80",
    badge: "EXCLUSIVE",
  },
];

export function OfferBanner() {
  const [cur, setCur] = useState(0);
  const prev = () => setCur(c => (c - 1 + banners.length) % banners.length);
  const next = () => setCur(c => (c + 1) % banners.length);

  useEffect(() => {
    const t = setInterval(next, 4500);
    return () => clearInterval(t);
  }, []);

  const b = banners[cur];

  return (
    <div className="relative w-full overflow-hidden" style={{ height: "200px" }}>
      <AnimatePresence mode="wait">
        <motion.div key={cur}
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -60 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0 flex overflow-hidden"
          style={{ background: b.bg }}>

          {/* Left content */}
          <div className="flex-1 flex flex-col justify-center px-6 relative z-10">
            <div className="inline-flex items-center gap-1.5 mb-3">
              <span className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full text-black"
                style={{ background: b.accent }}>
                {b.badge}
              </span>
            </div>
            <div className="text-sm font-bold mb-1" style={{ color: b.accent }}>{b.tag}</div>
            <h2 className="text-3xl font-black text-white leading-tight mb-1">{b.headline}</h2>
            <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.6)" }}>{b.sub}</p>
            <button className="self-start px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest text-black transition-all hover:opacity-90 active:scale-95"
              style={{ background: b.accent }}>
              {b.cta} →
            </button>
          </div>

          {/* Right image */}
          <div className="w-[45%] relative overflow-hidden">
            <img src={b.img} alt="" className="w-full h-full object-cover opacity-60" />
            <div className="absolute inset-0" style={{ background: `linear-gradient(to right, ${b.bg.split(",")[0].replace("linear-gradient(135deg,","")} 0%, transparent 100%)` }} />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Arrows */}
      <button onClick={prev} className="absolute left-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full flex items-center justify-center transition-all"
        style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(8px)" }}>
        <ChevronLeft className="w-4 h-4 text-white" />
      </button>
      <button onClick={next} className="absolute right-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full flex items-center justify-center transition-all"
        style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(8px)" }}>
        <ChevronRight className="w-4 h-4 text-white" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-20">
        {banners.map((_, i) => (
          <button key={i} onClick={() => setCur(i)}
            className="rounded-full transition-all duration-300"
            style={{ width: i === cur ? "20px" : "6px", height: "6px", background: i === cur ? b.accent : "rgba(255,255,255,0.3)" }} />
        ))}
      </div>
    </div>
  );
}
