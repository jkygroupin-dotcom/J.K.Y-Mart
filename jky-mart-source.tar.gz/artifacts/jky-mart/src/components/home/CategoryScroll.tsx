import { useLocation } from "wouter";
import {
  Shirt, Carrot, ShoppingBasket, Zap, Headphones,
  Smartphone, Camera, Wind, Coffee, Laptop, Watch, Sparkles,
} from "lucide-react";

const cats = [
  { label: "Fashion",     slug: "fashion",     icon: Shirt,          color: "#E91E8C" },
  { label: "Vegetables",  slug: "vegetables",  icon: Carrot,         color: "#4CAF50" },
  { label: "Grocery",     slug: "grocery",     icon: ShoppingBasket, color: "#FF6900" },
  { label: "Electronics", slug: "electronics", icon: Zap,            color: "#1A73E8" },
  { label: "Headphones",  slug: "headphones",  icon: Headphones,     color: "#9C27B0" },
  { label: "Phones",      slug: "phones",      icon: Smartphone,     color: "#00BCD4" },
  { label: "Camera",      slug: "camera",      icon: Camera,         color: "#FFA41C" },
  { label: "Iron",        slug: "iron",        icon: Wind,           color: "#607D8B" },
  { label: "Kitchen",     slug: "kitchen",     icon: Coffee,         color: "#E53935" },
  { label: "Laptop",      slug: "laptop",      icon: Laptop,         color: "#00ACC1" },
  { label: "Watches",     slug: "watches",     icon: Watch,          color: "#FFC107" },
  { label: "Beauty",      slug: "beauty",      icon: Sparkles,       color: "#F06292" },
];

export function CategoryScroll() {
  const [, setLocation] = useLocation();

  return (
    <div className="overflow-x-auto no-scrollbar py-3 px-2" style={{ background: "#0F1015" }}>
      <div className="flex gap-3" style={{ width: "max-content" }}>
        {cats.map(({ label, slug, icon: Icon, color }) => (
          <button
            key={slug}
            onClick={() => setLocation(`/category/${slug}`)}
            className="flex flex-col items-center gap-2 group transition-all active:scale-95"
            style={{ width: "64px" }}
            data-testid={`category-chip-${slug}`}
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all group-hover:scale-105"
              style={{ background: `${color}15`, border: `1.5px solid ${color}30` }}>
              <Icon className="w-6 h-6 transition-colors" style={{ color }} strokeWidth={1.8} />
            </div>
            <span className="text-[10px] font-semibold text-center leading-tight" style={{ color: "#8D9096" }}>
              {label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
