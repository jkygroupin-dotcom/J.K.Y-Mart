import { Truck, RotateCcw, Shield, Headphones } from "lucide-react";

const perks = [
  { icon: Truck,       label: "FREE Delivery",   sub: "Orders above ₹499",   color: "#00A650" },
  { icon: RotateCcw,   label: "Easy Returns",    sub: "10-day hassle-free",   color: "#1A73E8" },
  { icon: Shield,      label: "Secure Payment",  sub: "100% protected",       color: "#FF6900" },
  { icon: Headphones,  label: "24/7 Support",    sub: "Always here for you",  color: "#FFA41C" },
];

export function RewardSection() {
  return (
    <div className="grid grid-cols-4 divide-x" style={{ background: "#0F1015", borderTop: "1px solid rgba(255,255,255,0.06)", borderBottom: "1px solid rgba(255,255,255,0.06)", divideColor: "rgba(255,255,255,0.06)" }}>
      {perks.map(({ icon: Icon, label, sub, color }) => (
        <div key={label} className="flex flex-col items-center justify-center py-3 gap-1 px-2">
          <div className="w-7 h-7 rounded-full flex items-center justify-center mb-0.5"
            style={{ background: `${color}15` }}>
            <Icon className="w-3.5 h-3.5" style={{ color }} strokeWidth={2} />
          </div>
          <div className="text-[10px] font-bold text-center leading-tight" style={{ color: "#E2E8F0" }}>{label}</div>
          <div className="text-[9px] text-center leading-tight" style={{ color: "#5C5F69" }}>{sub}</div>
        </div>
      ))}
    </div>
  );
}
