import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Search, MapPin, ChevronDown, ShoppingCart, Menu, X } from "lucide-react";
import { products } from "@/data/products";
import { useCart } from "@/context/CartContext";

const navLinks = [
  { label: "All", slug: "" },
  { label: "Fashion", slug: "fashion" },
  { label: "Electronics", slug: "electronics" },
  { label: "Grocery", slug: "grocery" },
  { label: "Vegetables", slug: "vegetables" },
  { label: "Phones", slug: "phones" },
  { label: "Headphones", slug: "headphones" },
  { label: "Laptops", slug: "laptop" },
  { label: "Watches", slug: "watches" },
  { label: "Beauty", slug: "beauty" },
  { label: "Kitchen", slug: "kitchen" },
  { label: "Camera", slug: "camera" },
];

export default function Header() {
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const [, setLocation] = useLocation();
  const { itemCount } = useCart();
  const inputRef = useRef<HTMLInputElement>(null);

  const suggestions = query.length > 1
    ? products.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.brand.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 7)
    : [];

  return (
    <header className="sticky top-0 z-50 w-full" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── ROW 1: Main Header ── */}
      <div className="flex items-center gap-3 px-4 py-2.5" style={{ background: "#131921" }}>

        {/* Logo */}
        <Link href="/" className="flex items-center gap-1.5 shrink-0 group" data-testid="header-logo">
          <div className="w-8 h-8 rounded flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #FF6900, #FF3D00)" }}>
            <ShoppingCart className="w-4.5 h-4.5 text-white" strokeWidth={2.5} />
          </div>
          <div className="leading-none">
            <div className="text-base font-black tracking-tight" style={{ color: "#FF6900", fontFamily: "'Rajdhani', sans-serif", fontSize: "18px" }}>JKY</div>
            <div className="text-[8px] font-bold uppercase tracking-widest" style={{ color: "#FFD700", marginTop: "-2px" }}>Mart</div>
          </div>
        </Link>

        {/* Deliver to */}
        <button className="hidden sm:flex flex-col items-start px-2 py-1 rounded hover:outline hover:outline-1 transition-all shrink-0"
          style={{ outlineColor: "white" }}>
          <span className="text-[10px]" style={{ color: "#8D9096" }}>Deliver to</span>
          <div className="flex items-center gap-0.5">
            <MapPin className="w-3 h-3" style={{ color: "#FFA41C" }} />
            <span className="text-xs font-bold" style={{ color: "#F2F2F2" }}>India</span>
            <ChevronDown className="w-3 h-3" style={{ color: "#F2F2F2" }} />
          </div>
        </button>

        {/* Search — full width */}
        <div className="flex-1 relative" onBlur={e => { if (!e.currentTarget.contains(e.relatedTarget)) { setFocused(false); } }}>
          <div className="flex items-center rounded-lg overflow-hidden h-10"
            style={{ background: focused ? "#fff" : "#e8e8e8", boxShadow: focused ? "0 0 0 3px rgba(255,105,0,0.5)" : "none" }}>
            <div className="px-3 h-full flex items-center border-r" style={{ borderColor: "#cdcdcd" }}>
              <Search className="w-4 h-4" style={{ color: "#555" }} />
            </div>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onFocus={() => setFocused(true)}
              placeholder="Search JKY Mart..."
              className="flex-1 h-full px-3 text-sm outline-none"
              style={{ background: "transparent", color: "#111", fontFamily: "'Inter',sans-serif" }}
              data-testid="header-search"
            />
            {query && (
              <button className="px-2" onClick={() => setQuery("")}>
                <X className="w-4 h-4" style={{ color: "#555" }} />
              </button>
            )}
            <button className="px-3 h-full flex items-center rounded-r-lg"
              style={{ background: "#FF6900", minWidth: "42px" }}>
              <Search className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Suggestions */}
          {focused && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 rounded-lg overflow-hidden z-50 shadow-2xl"
              style={{ background: "#fff", border: "1px solid #ddd" }}>
              {suggestions.map(p => (
                <button key={p.id} tabIndex={0}
                  onMouseDown={() => { setLocation(`/product/${p.id}`); setQuery(""); setFocused(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-gray-50"
                  style={{ borderBottom: "1px solid #f0f0f0" }}
                  data-testid={`search-suggestion-${p.id}`}>
                  <img src={p.images[0]} alt={p.name} className="w-8 h-8 rounded object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-gray-900 truncate font-medium">{p.name}</div>
                    <div className="text-xs text-gray-400">{p.brand} · ₹{p.price.toLocaleString()}</div>
                  </div>
                  <Search className="w-3.5 h-3.5 text-gray-300 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Account */}
        <Link href="/account" className="hidden sm:flex flex-col items-start px-2 py-1 rounded hover:outline hover:outline-1 transition-all shrink-0"
          style={{ outlineColor: "white" }}>
          <span className="text-[10px]" style={{ color: "#8D9096" }}>Hello, Sign in</span>
          <div className="flex items-center gap-0.5">
            <span className="text-xs font-bold" style={{ color: "#F2F2F2" }}>Account & Lists</span>
            <ChevronDown className="w-3 h-3" style={{ color: "#F2F2F2" }} />
          </div>
        </Link>

        {/* Cart */}
        <Link href="/cart" className="flex items-center gap-1.5 px-2 py-1 rounded hover:outline hover:outline-1 transition-all shrink-0 relative"
          style={{ outlineColor: "white" }} data-testid="header-cart">
          <div className="relative">
            <ShoppingCart className="w-7 h-7" style={{ color: "#F2F2F2" }} />
            <span className="absolute -top-1.5 left-4 min-w-[18px] h-[18px] rounded-full text-[11px] font-black flex items-center justify-center px-0.5"
              style={{ background: "#FF6900", color: "white" }}>
              {itemCount > 0 ? (itemCount > 99 ? "99+" : itemCount) : "0"}
            </span>
          </div>
          <span className="text-sm font-bold hidden sm:block" style={{ color: "#F2F2F2", marginTop: "8px" }}>Cart</span>
        </Link>
      </div>

      {/* ── ROW 2: Category Nav Bar ── */}
      <div className="flex items-center overflow-x-auto no-scrollbar px-2" style={{ background: "#232F3E", height: "38px" }}>
        <button className="flex items-center gap-1.5 px-3 h-full text-xs font-bold whitespace-nowrap transition-colors hover:outline hover:outline-1 hover:outline-white rounded"
          style={{ color: "#F2F2F2" }}>
          <Menu className="w-4 h-4" />
          All
        </button>
        {navLinks.slice(1).map(link => (
          <button key={link.slug}
            onClick={() => setLocation(link.slug ? `/category/${link.slug}` : "/categories")}
            className="px-3 h-full text-xs font-semibold whitespace-nowrap transition-colors hover:outline hover:outline-1 hover:outline-white rounded"
            style={{ color: "#F2F2F2" }}>
            {link.label}
          </button>
        ))}
        <button className="px-3 h-full text-xs font-bold whitespace-nowrap rounded" style={{ color: "#FF6900" }}>
          🔥 Today's Deals
        </button>
      </div>
    </header>
  );
}
