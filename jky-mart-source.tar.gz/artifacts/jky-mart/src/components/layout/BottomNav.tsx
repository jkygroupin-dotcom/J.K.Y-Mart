import { Link, useLocation } from "wouter";
import { Home, Play, Grid3X3, ShoppingCart, User } from "lucide-react";
import { useCart } from "@/context/CartContext";

const navItems = [
  { name: "Home",  path: "/",          icon: Home },
  { name: "Play",  path: "/play",       icon: Play },
  { name: "Shop",  path: "/categories", icon: Grid3X3 },
  { name: "Cart",  path: "/cart",       icon: ShoppingCart },
  { name: "You",   path: "/account",    icon: User },
];

export default function BottomNav() {
  const [location] = useLocation();
  const { itemCount } = useCart();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50"
      style={{ background: "#131921", borderTop: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 -4px 24px rgba(0,0,0,0.6)" }}>
      <div className="flex items-center justify-around py-1.5 px-1 max-w-lg mx-auto">
        {navItems.map(item => {
          const isActive = location === item.path
            || (item.path === "/categories" && location.startsWith("/category"));
          return (
            <Link key={item.name} href={item.path} data-testid={`nav-${item.name.toLowerCase()}`}>
              <div className="flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-lg cursor-pointer transition-all"
                style={{ background: isActive ? "rgba(255,105,0,0.12)" : "transparent" }}>
                <div className="relative">
                  <item.icon className="w-5 h-5 transition-all" strokeWidth={isActive ? 2.5 : 1.8}
                    style={{ color: isActive ? "#FF6900" : "#8D9096" }} />
                  {item.name === "Cart" && itemCount > 0 && (
                    <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 rounded-full text-[9px] font-black flex items-center justify-center px-0.5"
                      style={{ background: "#FF6900", color: "white" }}>
                      {itemCount > 9 ? "9+" : itemCount}
                    </span>
                  )}
                </div>
                <span className="text-[9px] font-bold uppercase tracking-wider transition-all"
                  style={{ color: isActive ? "#FF6900" : "#5C5F69" }}>
                  {item.name}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
