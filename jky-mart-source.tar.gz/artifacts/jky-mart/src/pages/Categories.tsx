import { Link } from "wouter";
import { categories } from "@/data/products";
import { Laptop, Smartphone, Headphones, Camera, Watch, Shirt, ShoppingBasket, Carrot, Coffee, Sparkles } from "lucide-react";
import Header from "@/components/layout/Header";

const categoryIcons: Record<string, any> = {
  "Fashion": Shirt,
  "Vegetables": Carrot,
  "Grocery": ShoppingBasket,
  "Electronics": Smartphone,
  "Headphones": Headphones,
  "Phones": Smartphone,
  "Camera": Camera,
  "Kitchen": Coffee,
  "Laptop": Laptop,
  "Watches": Watch,
  "Beauty": Sparkles,
  "Iron": Sparkles
};

export default function Categories() {
  return (
    <div className="min-h-[100dvh] w-full flex flex-col text-white pb-20">
      <Header />
      <div className="flex-1 max-w-7xl mx-auto w-full p-4">
        <h1 className="text-3xl font-bold mb-6 mt-4">All Categories</h1>
        
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
          {categories.map((cat) => {
            const Icon = categoryIcons[cat] || Sparkles;
            return (
              <Link key={cat} href={`/?category=${cat.toLowerCase()}`} className="group">
                <div className="glass-card rounded-2xl aspect-square flex flex-col items-center justify-center p-4 hover:bg-white/10 transition-all cursor-pointer">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-white/5 to-white/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-white/80 group-hover:text-primary" />
                  </div>
                  <span className="text-xs font-medium text-center">{cat}</span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
