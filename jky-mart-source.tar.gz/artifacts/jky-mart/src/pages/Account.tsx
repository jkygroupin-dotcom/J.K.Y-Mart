import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { User, Package, Heart, Settings, LogOut, ChevronRight, Star, MapPin } from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";
import { products } from "@/data/products";
import { ProductCard } from "@/components/shared/ProductCard";
import Header from "@/components/layout/Header";

type Tab = "profile" | "orders" | "wishlist";

const mockOrders = [
  { id: "JKY20240501", name: "Aura Pro Wireless Headphones", status: "Delivered", date: "May 1, 2024", price: 12999, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80" },
  { id: "JKY20240415", name: "Midnight Silk Kurta Set", status: "Processing", date: "Apr 15, 2024", price: 4500, image: "https://images.unsplash.com/photo-1596455607563-ad6193f76b17?w=200&q=80" },
  { id: "JKY20240402", name: "Chronograph Obsidian Watch", status: "Shipped", date: "Apr 2, 2024", price: 24500, image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=200&q=80" },
];

const statusColors: Record<string, string> = {
  "Delivered": "text-green-400",
  "Processing": "text-yellow-400",
  "Shipped": "text-blue-400",
};

export default function Account() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignup, setIsSignup] = useState(false);
  const { wishlistIds } = useWishlist();
  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  if (!isLoggedIn) {
    return (
      <div className="min-h-[100dvh] w-full text-white pb-28">
        <Header />
        <div className="max-w-md mx-auto p-6 flex flex-col items-center justify-center min-h-[70vh]">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full"
          >
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#FF512F] to-[#DD2476] flex items-center justify-center mx-auto mb-6">
              <User className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-center mb-1">
              {isSignup ? "Create Account" : "Welcome Back"}
            </h1>
            <p className="text-white/40 text-center text-sm mb-8">
              {isSignup ? "Join JKY Mart for exclusive deals" : "Sign in to your JKY Mart account"}
            </p>

            <div className="glass-card rounded-2xl p-6 space-y-4">
              {isSignup && (
                <div>
                  <label className="text-xs text-white/50 mb-1.5 block uppercase tracking-wider">Full Name</label>
                  <input
                    type="text"
                    placeholder="Your name"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-primary/50 transition-colors"
                    data-testid="input-name"
                  />
                </div>
              )}
              <div>
                <label className="text-xs text-white/50 mb-1.5 block uppercase tracking-wider">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-primary/50 transition-colors"
                  data-testid="input-email"
                />
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1.5 block uppercase tracking-wider">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-primary/50 transition-colors"
                  data-testid="input-password"
                />
              </div>
              <button
                onClick={() => setIsLoggedIn(true)}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF512F] to-[#DD2476] text-white font-bold hover:shadow-[0_0_25px_rgba(221,36,118,0.4)] transition-all active:scale-[0.98]"
                data-testid="btn-login"
              >
                {isSignup ? "Create Account" : "Sign In"}
              </button>
              <div className="text-center text-sm text-white/40">
                {isSignup ? "Already have an account? " : "Don't have an account? "}
                <button
                  className="text-primary hover:underline"
                  onClick={() => setIsSignup(!isSignup)}
                  data-testid="btn-toggle-auth"
                >
                  {isSignup ? "Sign In" : "Sign Up"}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] w-full text-white pb-28">
      <Header />
      <div className="max-w-2xl mx-auto p-4">
        {/* Profile Hero */}
        <div className="glass-card rounded-2xl p-5 flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#FF512F] to-[#DD2476] flex items-center justify-center text-2xl font-bold shrink-0">
            J
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-lg">JKY User</h2>
            <p className="text-white/40 text-sm">{email || "user@jkymart.com"}</p>
            <div className="flex items-center gap-1 mt-1">
              <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
              <span className="text-xs text-white/60">Premium Member</span>
            </div>
          </div>
          <button
            onClick={() => setIsLoggedIn(false)}
            className="p-2 rounded-full hover:bg-white/10 text-white/40 hover:text-white transition-colors"
            data-testid="btn-logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {(["profile", "orders", "wishlist"] as Tab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold capitalize transition-all ${
                activeTab === tab
                  ? "bg-gradient-to-r from-[#FF512F] to-[#DD2476] text-white"
                  : "glass-card text-white/60 hover:text-white"
              }`}
              data-testid={`tab-${tab}`}
            >
              {tab}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {activeTab === "profile" && (
            <motion.div
              key="profile"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-3"
            >
              {[
                { icon: User, label: "Edit Profile" },
                { icon: MapPin, label: "Saved Addresses" },
                { icon: Package, label: "Track Order" },
                { icon: Settings, label: "Settings" },
              ].map(({ icon: Icon, label }) => (
                <button
                  key={label}
                  className="glass-card rounded-xl p-4 w-full flex items-center gap-3 hover:bg-white/10 transition-colors"
                  data-testid={`profile-${label.toLowerCase().replace(/ /g, "-")}`}
                >
                  <div className="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center">
                    <Icon className="w-4 h-4 text-white/70" />
                  </div>
                  <span className="font-medium text-sm flex-1 text-left">{label}</span>
                  <ChevronRight className="w-4 h-4 text-white/30" />
                </button>
              ))}
            </motion.div>
          )}

          {activeTab === "orders" && (
            <motion.div
              key="orders"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-3"
            >
              {mockOrders.map((order) => (
                <div
                  key={order.id}
                  className="glass-card rounded-2xl p-4 flex gap-4 items-center"
                  data-testid={`order-${order.id}`}
                >
                  <img src={order.image} alt={order.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm line-clamp-1">{order.name}</div>
                    <div className="text-xs text-white/40 mt-0.5">{order.date} · #{order.id}</div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold">₹{order.price.toLocaleString()}</span>
                      <span className={`text-xs font-semibold ${statusColors[order.status]}`}>{order.status}</span>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === "wishlist" && (
            <motion.div
              key="wishlist"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {wishlistProducts.length === 0 ? (
                <div className="text-center py-16 text-white/40">
                  <Heart className="w-12 h-12 mx-auto mb-4 text-white/20" />
                  <p>No items in your wishlist yet</p>
                  <p className="text-sm mt-1">Tap the heart on any product to save it</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  {wishlistProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
