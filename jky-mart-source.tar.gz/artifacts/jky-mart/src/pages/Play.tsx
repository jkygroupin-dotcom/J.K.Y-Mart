import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, Share2, ShoppingBag } from "lucide-react";
import { products } from "@/data/products";
import { useCart } from "@/context/CartContext";

export default function Play() {
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();
  const reels = products.slice(0, 5); // Use first 5 products for reels

  return (
    <div className="h-[100dvh] w-full bg-black overflow-y-scroll snap-y snap-mandatory no-scrollbar text-white relative pb-20">
      {reels.map((product, index) => (
        <div key={product.id} className="h-full w-full snap-start relative flex items-center justify-center">
          {/* Simulated Video Background */}
          <div className="absolute inset-0">
            <img 
              src={product.images[0]} 
              alt={product.name}
              className="w-full h-full object-cover opacity-60 scale-105 blur-sm"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/40 to-black/80" />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 flex items-center justify-center p-8"
              onClick={() => setLocation(`/product/${product.id}`)}
            >
              <img 
                src={product.images[0]} 
                alt={product.name}
                className="w-full max-w-sm aspect-[3/4] object-cover rounded-3xl shadow-2xl shadow-primary/20"
              />
            </motion.div>
          </div>

          {/* Overlay Actions */}
          <div className="absolute right-4 bottom-32 flex flex-col items-center gap-6 z-10">
            <button className="flex flex-col items-center gap-1 group">
              <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center group-hover:bg-primary/50 transition-colors">
                <Heart className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium">{product.rating * 10}k</span>
            </button>
            <button className="flex flex-col items-center gap-1 group">
              <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center group-hover:bg-white/30 transition-colors">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium">{product.reviewCount}</span>
            </button>
            <button className="flex flex-col items-center gap-1 group">
              <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center group-hover:bg-white/30 transition-colors">
                <Share2 className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium">Share</span>
            </button>
          </div>

          {/* Product Info */}
          <div className="absolute bottom-24 left-4 right-20 z-10">
            <div className="glass-card rounded-2xl p-4 flex gap-4 items-center">
              <div className="flex-1">
                <h3 className="font-bold text-lg leading-tight line-clamp-1">{product.name}</h3>
                <p className="text-white/60 text-sm">{product.brand}</p>
                <p className="text-xl font-black mt-1">₹{product.price.toLocaleString()}</p>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(product);
                }}
                className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#FF512F] to-[#DD2476] flex items-center justify-center shadow-lg shrink-0"
              >
                <ShoppingBag className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
