import { useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { ChevronLeft, SlidersHorizontal, Grid2X2, List } from "lucide-react";
import { useState } from "react";
import { products, categoryFilterMap } from "@/data/products";
import { ProductCard } from "@/components/shared/ProductCard";
import { Shirt, Carrot, ShoppingBasket, Zap, Headphones, Smartphone, Camera, Wind, Coffee, Laptop, Watch, Sparkles } from "lucide-react";
import Header from "@/components/layout/Header";

const categoryMeta: Record<string, { label: string; icon: React.ComponentType<{ className?: string }>; description: string; color: string; }> = {
  fashion:     { label: "Fashion",     icon: Shirt,          description: "Kurtas, jeans, shirts, sarees, footwear & more",    color: "#E91E8C" },
  vegetables:  { label: "Vegetables",  icon: Carrot,         description: "Fresh, organic & farm-direct vegetables",           color: "#4CAF50" },
  grocery:     { label: "Grocery",     icon: ShoppingBasket, description: "Rice, dal, oil, atta & everyday essentials",        color: "#FF6900" },
  electronics: { label: "Electronics", icon: Zap,            description: "TVs, accessories, gadgets & smart devices",        color: "#1A73E8" },
  headphones:  { label: "Headphones",  icon: Headphones,     description: "Wireless, ANC, earbuds, gaming headsets",          color: "#9C27B0" },
  phones:      { label: "Phones",      icon: Smartphone,     description: "Android, iPhone & flagship smartphones",           color: "#00BCD4" },
  camera:      { label: "Camera",      icon: Camera,         description: "DSLR, mirrorless, action cams & polaroid",         color: "#FFA41C" },
  iron:        { label: "Iron",        icon: Wind,           description: "Steam irons, garment steamers & cordless irons",   color: "#607D8B" },
  kitchen:     { label: "Kitchen",     icon: Coffee,         description: "Coffee makers, air fryers, mixers & cookware",     color: "#E53935" },
  laptop:      { label: "Laptop",      icon: Laptop,         description: "MacBook, gaming rigs, ultrabooks & more",          color: "#00ACC1" },
  watches:     { label: "Watches",     icon: Watch,          description: "Smartwatches, luxury & casual timepieces",         color: "#FFC107" },
  beauty:      { label: "Beauty",      icon: Sparkles,       description: "Skincare, makeup, haircare & grooming",            color: "#F06292" },
};

type SortKey = "default" | "price_asc" | "price_desc" | "rating" | "discount";

export default function CategoryLanding() {
  const { name } = useParams<{ name: string }>();
  const [, setLocation] = useLocation();
  const [gridView, setGridView] = useState(true);
  const [sort, setSort] = useState<SortKey>("default");

  const slug = (name || "").toLowerCase();
  const meta = categoryMeta[slug];
  const catKeys = categoryFilterMap[slug] || [slug];
  let filtered = products.filter(p => catKeys.includes(p.category));

  if (sort === "price_asc")  filtered = [...filtered].sort((a, b) => a.price - b.price);
  if (sort === "price_desc") filtered = [...filtered].sort((a, b) => b.price - a.price);
  if (sort === "rating")     filtered = [...filtered].sort((a, b) => b.rating - a.rating);
  if (sort === "discount")   filtered = [...filtered].sort((a, b) => b.discountPercentage - a.discountPercentage);

  if (!meta) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center" style={{ background: "#07080C" }}>
        <div className="text-center">
          <p className="mb-4 text-sm" style={{ color: "#8D9096" }}>Category not found</p>
          <button onClick={() => setLocation("/")} className="text-sm underline" style={{ color: "#FF6900" }}>Go Home</button>
        </div>
      </div>
    );
  }

  const Icon = meta.icon;

  return (
    <div className="min-h-[100dvh] w-full pb-28" style={{ background: "#07080C" }}>
      <Header />

      {/* Category hero bar */}
      <div className="flex items-center gap-3 px-4 py-3" style={{ background: "#131921", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <button onClick={() => setLocation("/")}
          className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors hover:bg-white/10"
          data-testid="btn-back">
          <ChevronLeft className="w-5 h-5" style={{ color: "#C8CAD0" }} />
        </button>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: `${meta.color}18`, border: `1.5px solid ${meta.color}35` }}>
          <Icon className="w-5 h-5" style={{ color: meta.color } as React.CSSProperties} />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-black leading-tight" style={{ color: "#F2F2F2" }}>{meta.label}</h1>
          <p className="text-[10px] truncate" style={{ color: "#8D9096" }}>{meta.description}</p>
        </div>
        <div className="text-xs font-semibold shrink-0" style={{ color: "#8D9096" }}>
          {filtered.length} items
        </div>
      </div>

      {/* Sort + View toggle bar */}
      <div className="flex items-center gap-2 px-3 py-2 overflow-x-auto no-scrollbar"
        style={{ background: "#0F1015", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <SlidersHorizontal className="w-3.5 h-3.5 shrink-0" style={{ color: "#5C5F69" }} />
        <span className="text-[10px] font-bold uppercase tracking-wider shrink-0" style={{ color: "#5C5F69" }}>Sort:</span>
        {([
          ["default",    "Relevance"],
          ["discount",   "Best Discount"],
          ["price_asc",  "Price: Low→High"],
          ["price_desc", "Price: High→Low"],
          ["rating",     "Top Rated"],
        ] as [SortKey, string][]).map(([key, label]) => (
          <button key={key} onClick={() => setSort(key)}
            className="text-[10px] font-bold px-2.5 py-1 rounded-full whitespace-nowrap transition-all shrink-0"
            style={{
              background: sort === key ? meta.color : "rgba(255,255,255,0.05)",
              color: sort === key ? "white" : "#8D9096",
              border: sort === key ? `1px solid ${meta.color}` : "1px solid rgba(255,255,255,0.08)",
            }}>
            {label}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1 shrink-0">
          <button onClick={() => setGridView(true)} className="p-1.5 rounded transition-colors"
            style={{ background: gridView ? "rgba(255,255,255,0.1)" : "transparent", color: gridView ? "#F2F2F2" : "#5C5F69" }}>
            <Grid2X2 className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setGridView(false)} className="p-1.5 rounded transition-colors"
            style={{ background: !gridView ? "rgba(255,255,255,0.1)" : "transparent", color: !gridView ? "#F2F2F2" : "#5C5F69" }}>
            <List className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Products */}
      <div className="px-3 py-3">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <Icon className="w-16 h-16 mb-4 opacity-15" style={{ color: meta.color } as React.CSSProperties} />
            <p className="text-sm" style={{ color: "#5C5F69" }}>No products in this category yet</p>
          </div>
        ) : gridView ? (
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((product, i) => (
              <motion.div key={product.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.3, ease: [0.22, 1, 0.36, 1] }}>
                <ProductCard product={product} size="sm" />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map((product, i) => (
              <motion.div key={product.id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04, duration: 0.3 }}>
                <ProductCard product={product} horizontal />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
