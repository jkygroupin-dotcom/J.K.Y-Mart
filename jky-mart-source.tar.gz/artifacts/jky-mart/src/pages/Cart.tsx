import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight, Tag, Shield } from "lucide-react";
import { useCart } from "@/context/CartContext";
import Header from "@/components/layout/Header";

export default function Cart() {
  const { items, removeFromCart, updateQuantity, subtotal, itemCount } = useCart();
  const delivery = subtotal > 499 ? 0 : 79;
  const savings = items.reduce((acc, i) => acc + (i.product.originalPrice - i.product.price) * i.quantity, 0);
  const total = subtotal + delivery;

  return (
    <div className="min-h-[100dvh] w-full pb-28" style={{ background: "#07080C" }}>
      <Header />

      <div className="max-w-2xl mx-auto">
        {/* Cart title */}
        <div className="px-4 py-3 flex items-center gap-2" style={{ background: "#13141B", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <ShoppingCart className="w-5 h-5" style={{ color: "#FF6900" }} />
          <h1 className="text-base font-black" style={{ color: "#F2F2F2" }} data-testid="cart-title">
            Shopping Cart
          </h1>
          {itemCount > 0 && (
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full ml-1" style={{ background: "rgba(255,105,0,0.15)", color: "#FF6900" }}>
              {itemCount} {itemCount === 1 ? "item" : "items"}
            </span>
          )}
        </div>

        {items.length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-24 text-center px-8">
            <div className="w-24 h-24 rounded-full flex items-center justify-center mb-6"
              style={{ background: "rgba(255,105,0,0.08)", border: "2px dashed rgba(255,105,0,0.2)" }}>
              <ShoppingCart className="w-10 h-10" style={{ color: "#FF6900", opacity: 0.5 }} />
            </div>
            <h2 className="text-xl font-black mb-2" style={{ color: "#F2F2F2" }}>Your cart is empty</h2>
            <p className="text-sm mb-8" style={{ color: "#8D9096" }}>Add items to your cart to get started</p>
            <Link href="/">
              <button className="px-8 py-3 rounded-lg font-bold text-sm transition-all active:scale-95"
                style={{ background: "linear-gradient(180deg, #F0A30A, #FF6900)", color: "#111", border: "1px solid #C45500" }}
                data-testid="btn-continue-shopping">
                Continue Shopping
              </button>
            </Link>
          </motion.div>
        ) : (
          <div className="flex flex-col gap-0">

            {/* Savings banner */}
            {savings > 0 && (
              <div className="flex items-center gap-2 px-4 py-2.5" style={{ background: "rgba(0,166,80,0.08)", borderBottom: "1px solid rgba(0,166,80,0.15)" }}>
                <Tag className="w-3.5 h-3.5 shrink-0" style={{ color: "#00A650" }} />
                <span className="text-xs font-bold" style={{ color: "#00A650" }}>
                  You're saving ₹{savings.toLocaleString()} on this order! 🎉
                </span>
              </div>
            )}

            {/* Items */}
            <div style={{ background: "#0F1015" }}>
              <AnimatePresence>
                {items.map((item) => (
                  <motion.div key={item.product.id} layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex gap-3 px-3 py-3"
                    style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
                    data-testid={`cart-item-${item.product.id}`}>

                    <Link href={`/product/${item.product.id}`} className="shrink-0">
                      <div className="w-20 h-20 rounded-xl overflow-hidden" style={{ background: "#1C1E27" }}>
                        <img src={item.product.images[0]} alt={item.product.name}
                          className="w-full h-full object-cover" />
                      </div>
                    </Link>

                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-semibold uppercase tracking-wider mb-0.5" style={{ color: "#1A73E8" }}>
                        {item.product.brand}
                      </div>
                      <Link href={`/product/${item.product.id}`}>
                        <h3 className="text-sm font-medium line-clamp-2 leading-snug mb-1.5" style={{ color: "#C8CAD0" }}>
                          {item.product.name}
                        </h3>
                      </Link>
                      <div className="flex items-baseline gap-1.5 mb-2">
                        <span className="text-base font-black" style={{ color: "#CC0000" }}>
                          ₹{(item.product.price * item.quantity).toLocaleString()}
                        </span>
                        {item.quantity > 1 && (
                          <span className="text-[10px]" style={{ color: "#8D9096" }}>
                            ₹{item.product.price.toLocaleString()} each
                          </span>
                        )}
                      </div>
                      {item.product.price > 499 && (
                        <div className="text-[10px] mb-2" style={{ color: "#00A650" }}>✓ FREE Delivery</div>
                      )}

                      {/* Controls */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center rounded-lg overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.12)" }}>
                          <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center transition-colors hover:bg-white/10"
                            style={{ color: "#F2F2F2" }}
                            data-testid={`btn-decrease-${item.product.id}`}>
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="w-8 h-8 flex items-center justify-center text-sm font-bold border-x"
                            style={{ color: "#F2F2F2", borderColor: "rgba(255,255,255,0.12)" }}
                            data-testid={`qty-${item.product.id}`}>
                            {item.quantity}
                          </span>
                          <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center transition-colors hover:bg-white/10"
                            style={{ color: "#F2F2F2" }}
                            data-testid={`btn-increase-${item.product.id}`}>
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <button onClick={() => removeFromCart(item.product.id)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors hover:bg-red-500/10"
                          style={{ color: "#CC0000" }}
                          data-testid={`btn-remove-${item.product.id}`}>
                          <Trash2 className="w-3.5 h-3.5" />
                          Remove
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* Order Summary */}
            <motion.div layout className="mx-3 mt-3 rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.08)" }}>
              <div className="px-4 py-2.5" style={{ background: "#13141B", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                <h2 className="text-sm font-black" style={{ color: "#F2F2F2" }}>Order Summary</h2>
              </div>
              <div className="px-4 py-3 space-y-2.5" style={{ background: "#0F1015" }}>
                <div className="flex justify-between text-sm" style={{ color: "#C8CAD0" }}>
                  <span>Price ({itemCount} items)</span>
                  <span>₹{(subtotal + savings).toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between text-sm font-semibold" style={{ color: "#00A650" }}>
                    <span>Discount</span>
                    <span>-₹{savings.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm" style={{ color: "#C8CAD0" }}>
                  <span>Delivery</span>
                  <span style={{ color: delivery === 0 ? "#00A650" : "#C8CAD0" }}>
                    {delivery === 0 ? "FREE" : `₹${delivery}`}
                  </span>
                </div>
                {delivery === 0 && (
                  <p className="text-[10px]" style={{ color: "#00A650" }}>Free delivery on orders above ₹499</p>
                )}
                <div className="h-px" style={{ background: "rgba(255,255,255,0.07)" }} />
                <div className="flex justify-between text-base font-black" style={{ color: "#F2F2F2" }}>
                  <span>Total Amount</span>
                  <span>₹{total.toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <div className="text-xs font-bold text-center py-2 rounded-lg" style={{ background: "rgba(0,166,80,0.1)", color: "#00A650" }}>
                    🎉 You save ₹{savings.toLocaleString()} on this order!
                  </div>
                )}
              </div>
              <div className="px-4 pb-4" style={{ background: "#0F1015" }}>
                <button className="w-full py-3.5 rounded-lg font-bold text-sm transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                  style={{ background: "linear-gradient(180deg, #F0A30A, #FF6900)", color: "#111", border: "1px solid #C45500", boxShadow: "0 3px 0 rgba(0,0,0,0.4)" }}
                  data-testid="btn-checkout">
                  Proceed to Checkout
                  <ArrowRight className="w-4 h-4" />
                </button>
                <div className="flex items-center justify-center gap-1.5 mt-3">
                  <Shield className="w-3 h-3" style={{ color: "#5C5F69" }} />
                  <span className="text-[10px]" style={{ color: "#5C5F69" }}>Safe & Secure Payments</span>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
                  {["UPI", "Visa", "Mastercard", "Netbanking", "Wallets", "EMI"].map(m => (
                    <span key={m} className="text-[9px] px-2 py-0.5 rounded-full font-semibold"
                      style={{ background: "rgba(255,255,255,0.05)", color: "#5C5F69", border: "1px solid rgba(255,255,255,0.07)" }}>
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>

            <div style={{ height: "12px" }} />
          </div>
        )}
      </div>
    </div>
  );
}
