import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowRight, Zap, Clock, Shirt, Coffee, Watch, Smartphone } from "lucide-react";
import Header from "@/components/layout/Header";
import { CategoryScroll } from "@/components/home/CategoryScroll";
import { OfferBanner } from "@/components/home/OfferBanner";
import { RewardSection } from "@/components/home/RewardSection";
import { ProductCard } from "@/components/shared/ProductCard";
import { products } from "@/data/products";

const electronics = products.filter(p => ["phones", "headphones", "laptop", "electronics", "camera"].includes(p.category));
const fashion     = products.filter(p => p.category === "fashion");
const grocery     = products.filter(p => ["grocery", "vegetables"].includes(p.category));
const kitchen     = products.filter(p => p.category === "kitchen");
const watches     = products.filter(p => p.category === "watches");
const flashDeals  = products.filter(p => p.discountPercentage >= 30).slice(0, 8);
const bestSellers = products.slice(0, 8);

// Countdown timer hook
function useCountdown(seconds: number) {
  const [left, setLeft] = useState(seconds);
  useEffect(() => {
    const t = setInterval(() => setLeft(l => l > 0 ? l - 1 : seconds), 1000);
    return () => clearInterval(t);
  }, [seconds]);
  const h = Math.floor(left / 3600);
  const m = Math.floor((left % 3600) / 60);
  const s = left % 60;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}

function TimerBox({ val }: { val: string }) {
  return (
    <div className="flex items-center gap-0.5">
      {val.split("").map((ch, i) => (
        ch === ":" ? (
          <span key={i} className="text-sm font-black" style={{ color: "#FF6900", margin: "0 1px" }}>:</span>
        ) : (
          <span key={i} className="text-xs font-black text-white w-5 h-6 rounded flex items-center justify-center"
            style={{ background: "#1C1E27", border: "1px solid rgba(255,255,255,0.1)" }}>
            {ch}
          </span>
        )
      ))}
    </div>
  );
}

interface SectionProps {
  title: string;
  eyebrow?: string;
  slug: string;
  items: typeof products;
  icon?: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  accentColor?: string;
}

function HorizontalSection({ title, eyebrow, slug, items, icon: Icon, accentColor = "#FF6900" }: SectionProps) {
  const [, setLocation] = useLocation();
  if (!items.length) return null;

  return (
    <section>
      <div className="flex items-center justify-between px-4 py-3"
        style={{ background: "#13141B", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="flex items-center gap-2.5">
          {Icon && (
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: `${accentColor}18`, border: `1px solid ${accentColor}30` }}>
              <Icon className="w-3.5 h-3.5" strokeWidth={2} style={{ color: accentColor } as React.CSSProperties} />
            </div>
          )}
          <div>
            {eyebrow && <div className="text-[9px] font-bold uppercase tracking-widest" style={{ color: accentColor }}>{eyebrow}</div>}
            <h2 className="text-sm font-black" style={{ color: "#F2F2F2" }}>{title}</h2>
          </div>
        </div>
        <button onClick={() => setLocation(`/category/${slug}`)}
          className="flex items-center gap-1 text-xs font-bold transition-colors group"
          style={{ color: "#1A73E8" }}>
          See All <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

      <div className="overflow-x-auto no-scrollbar px-3 py-3" style={{ background: "#0F1015" }}>
        <div className="flex gap-3" style={{ width: "max-content" }}>
          {items.slice(0, 8).map((p, i) => (
            <motion.div key={p.id}
              initial={{ opacity: 0, x: 12 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05, duration: 0.3 }}
              style={{ width: "150px" }}
              className="shrink-0">
              <ProductCard product={p} size="sm" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Category quick-links like Amazon's grid
const quickCats = [
  { label: "Fashion Deals",    slug: "fashion",     bg: "linear-gradient(135deg,#1A0A30,#3D1A6E)", img: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&q=80" },
  { label: "Electronics",      slug: "electronics", bg: "linear-gradient(135deg,#0A1628,#1A3866)", img: "https://images.unsplash.com/photo-1593359677879-a4bb92f4a833?w=400&q=80" },
  { label: "Fresh Grocery",    slug: "grocery",     bg: "linear-gradient(135deg,#0A2010,#1A4020)", img: "https://images.unsplash.com/photo-1543168256-418811576931?w=400&q=80" },
  { label: "Home & Kitchen",   slug: "kitchen",     bg: "linear-gradient(135deg,#2A1008,#4A2010)", img: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80" },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const countdown = useCountdown(7 * 3600 + 42 * 60 + 18);

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden" style={{ background: "#07080C" }}>
      <Header />

      {/* Hero Banner */}
      <OfferBanner />

      {/* Rewards strip */}
      <RewardSection />

      {/* Category icons */}
      <div className="divider" />
      <CategoryScroll />

      {/* ── Flash Deals ── */}
      <div className="divider" />
      <section>
        <div className="flex items-center justify-between px-4 py-3"
          style={{ background: "#13141B", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: "rgba(255,105,0,0.15)", border: "1px solid rgba(255,105,0,0.3)" }}>
              <Zap className="w-3.5 h-3.5" style={{ color: "#FF6900" }} strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-[9px] font-bold uppercase tracking-widest" style={{ color: "#FF6900" }}>Limited Time</div>
              <h2 className="text-sm font-black" style={{ color: "#F2F2F2" }}>Flash Deals</h2>
            </div>
            <div className="flex items-center gap-1.5 ml-2">
              <Clock className="w-3 h-3" style={{ color: "#FFA41C" }} />
              <TimerBox val={countdown} />
            </div>
          </div>
          <button onClick={() => setLocation("/categories")} className="text-xs font-bold" style={{ color: "#1A73E8" }}>
            See All →
          </button>
        </div>

        <div className="overflow-x-auto no-scrollbar px-3 py-3" style={{ background: "#0F1015" }}>
          <div className="flex gap-3" style={{ width: "max-content" }}>
            {flashDeals.map((p, i) => (
              <motion.div key={p.id}
                initial={{ opacity: 0, x: 12 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04, duration: 0.3 }}
                style={{ width: "150px" }}
                className="shrink-0">
                <ProductCard product={p} size="sm" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quick Category Grid (like Amazon's 4-box) ── */}
      <div className="divider" />
      <div className="px-3 py-3" style={{ background: "#0F1015" }}>
        <div className="grid grid-cols-2 gap-2.5">
          {quickCats.map(({ label, slug, bg, img }) => (
            <motion.button key={slug}
              onClick={() => setLocation(`/category/${slug}`)}
              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
              className="relative overflow-hidden rounded-xl text-left"
              style={{ height: "110px", background: bg }}>
              <img src={img} alt={label}
                className="absolute inset-0 w-full h-full object-cover opacity-30 transition-opacity group-hover:opacity-40" />
              <div className="absolute inset-0 p-3 flex flex-col justify-between">
                <div className="text-sm font-black text-white leading-tight">{label}</div>
                <div className="text-[10px] font-bold flex items-center gap-1" style={{ color: "#FF6900" }}>
                  Shop Now <ArrowRight className="w-3 h-3" />
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* ── Best Sellers Grid ── */}
      <div className="divider" />
      <section>
        <div className="flex items-center justify-between px-4 py-3"
          style={{ background: "#13141B", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div>
            <div className="text-[9px] font-bold uppercase tracking-widest mb-0.5" style={{ color: "#FFA41C" }}>Customers Love</div>
            <h2 className="text-sm font-black" style={{ color: "#F2F2F2" }}>Best Sellers</h2>
          </div>
          <button onClick={() => setLocation("/categories")} className="text-xs font-bold" style={{ color: "#1A73E8" }}>See All →</button>
        </div>
        <div className="px-3 py-3" style={{ background: "#0F1015" }}>
          <div className="grid grid-cols-2 gap-3">
            {bestSellers.map((p, i) => (
              <motion.div key={p.id}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04, duration: 0.3, ease: [0.22,1,0.36,1] }}>
                <ProductCard product={p} size="sm" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Promo Banner ── */}
      <div className="divider" />
      <div className="mx-3 my-3 rounded-xl overflow-hidden flex items-center justify-between px-5 py-4 relative"
        style={{ background: "linear-gradient(135deg, #FF6900 0%, #E53935 100%)", minHeight: "80px" }}>
        <div className="absolute right-0 top-0 w-32 h-32 rounded-full opacity-10" style={{ background: "white", transform: "translate(20%, -30%)" }} />
        <div className="relative z-10">
          <div className="text-[9px] font-black uppercase tracking-widest text-white/70 mb-0.5">Exclusive Offer</div>
          <div className="text-lg font-black text-white leading-tight">Extra 10% OFF</div>
          <div className="text-xs text-white/70 mt-0.5">Use code <strong>JKY10</strong> · All payment modes</div>
        </div>
        <div className="relative z-10 w-14 h-14 rounded-full bg-white/15 flex items-center justify-center border-2 border-white/30 shrink-0">
          <span className="text-white font-black text-base">10%</span>
        </div>
      </div>

      {/* ── Product Sections ── */}
      <div className="divider" />
      <HorizontalSection title="Electronics & Gadgets" eyebrow="Top Deals" slug="electronics" items={electronics} icon={Zap} accentColor="#1A73E8" />
      <div className="divider" />
      <HorizontalSection title="Fashion" eyebrow="New Arrivals" slug="fashion" items={fashion} icon={Shirt} accentColor="#E91E8C" />
      <div className="divider" />
      <HorizontalSection title="Smartphones" eyebrow="Best Value" slug="phones"
        items={products.filter(p => p.category === "phones")} icon={Smartphone} accentColor="#00BCD4" />
      <div className="divider" />
      <HorizontalSection title="Kitchen & Home" eyebrow="Top Picks" slug="kitchen" items={kitchen} icon={Coffee} accentColor="#FF6900" />
      <div className="divider" />
      <HorizontalSection title="Watches" eyebrow="Premium" slug="watches" items={watches} icon={Watch} accentColor="#FFA41C" />
      <div className="divider" />
      <HorizontalSection title="Fresh Grocery" eyebrow="Farm to Door" slug="grocery" items={grocery} icon={undefined} accentColor="#00A650" />

      {/* Bottom space */}
      <div style={{ height: "24px" }} />
    </div>
  );
}
