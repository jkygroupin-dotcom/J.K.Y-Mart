import { useState, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Star, ShoppingBag, ChevronLeft, Camera, Upload, X, Share2, Shirt } from "lucide-react";
import { products } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { ProductCard } from "@/components/shared/ProductCard";
import { cn } from "@/lib/utils";

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const product = products.find((p) => p.id === id);
  const related = products.filter((p) => p.id !== id && p.category === product?.category).slice(0, 4);

  const [selectedSize, setSelectedSize] = useState<string | null>(product?.sizes?.[0] || null);
  const [selectedColor, setSelectedColor] = useState<string | null>(product?.colors?.[0] || null);
  const [tryOnOpen, setTryOnOpen] = useState(false);
  const [tryOnImage, setTryOnImage] = useState<string | null>(null);
  const [addedToCart, setAddedToCart] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!product) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center text-white">
        <div className="text-center">
          <p className="text-white/40 mb-4">Product not found</p>
          <button onClick={() => setLocation("/")} className="text-primary underline">Go Home</button>
        </div>
      </div>
    );
  }

  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setTryOnImage(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-[100dvh] w-full text-white pb-28">
      {/* Back button */}
      <div className="fixed top-4 left-4 z-50">
        <button
          onClick={() => setLocation("/")}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:bg-black/60 transition-colors"
          data-testid="btn-back"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        <button
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:bg-black/60 transition-colors"
          data-testid="btn-share"
        >
          <Share2 className="w-4 h-4" />
        </button>
        <button
          onClick={() => toggleWishlist(product.id)}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:bg-black/60 transition-colors"
          data-testid="btn-wishlist"
        >
          <Heart className={cn("w-4 h-4", inWishlist && "fill-[#DD2476] text-[#DD2476]")} />
        </button>
      </div>

      {/* Product Image */}
      <div className="relative w-full aspect-square max-h-[55vh] overflow-hidden bg-white/5">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" style={{ background: "linear-gradient(to top, #0f0c29 0%, transparent 60%)" }} />
      </div>

      {/* Product Info */}
      <div className="px-4 -mt-8 relative z-10">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <div className="text-xs text-white/40 uppercase tracking-widest mb-1">{product.brand}</div>
            <h1 className="text-xl font-bold leading-tight" data-testid="product-name">{product.name}</h1>
          </div>
          <div className="shrink-0 flex items-center gap-1 bg-white/5 rounded-full px-3 py-1.5 border border-white/10">
            <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-bold">{product.rating}</span>
            <span className="text-xs text-white/40">({product.reviewCount})</span>
          </div>
        </div>

        {/* Price */}
        <div className="flex items-end gap-3 mb-4">
          <span className="text-3xl font-black text-white" data-testid="product-price">₹{product.price.toLocaleString()}</span>
          {product.originalPrice > product.price && (
            <>
              <span className="text-white/40 line-through text-base mb-1">₹{product.originalPrice.toLocaleString()}</span>
              <span className="mb-1 text-sm font-bold bg-gradient-to-r from-[#FF512F] to-[#DD2476] bg-clip-text text-transparent">
                {product.discountPercentage}% OFF
              </span>
            </>
          )}
        </div>

        {/* Sizes */}
        {product.sizes && product.sizes.length > 0 && (
          <div className="mb-4">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Size</div>
            <div className="flex gap-2 flex-wrap">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={cn(
                    "w-11 h-11 rounded-xl text-sm font-semibold transition-all border",
                    selectedSize === size
                      ? "bg-gradient-to-r from-[#FF512F] to-[#DD2476] border-transparent text-white shadow-[0_0_15px_rgba(221,36,118,0.4)]"
                      : "bg-white/5 border-white/10 text-white/60 hover:border-white/30"
                  )}
                  data-testid={`size-${size}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Colors */}
        {product.colors && product.colors.length > 0 && (
          <div className="mb-4">
            <div className="text-xs text-white/50 uppercase tracking-wider mb-2">Color</div>
            <div className="flex gap-2">
              {product.colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={cn(
                    "w-8 h-8 rounded-full transition-all border-2",
                    selectedColor === color ? "border-white scale-110 shadow-[0_0_12px_rgba(255,255,255,0.4)]" : "border-transparent"
                  )}
                  style={{ backgroundColor: color }}
                  data-testid={`color-${color}`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Description */}
        <div className="mb-6">
          <div className="text-xs text-white/50 uppercase tracking-wider mb-2">About this product</div>
          <p className="text-sm text-white/70 leading-relaxed">{product.description}</p>
        </div>

        {/* Virtual Try-On for fashion */}
        {(product.category === "fashion") && (
          <button
            onClick={() => setTryOnOpen(true)}
            className="w-full mb-4 py-3.5 rounded-2xl border border-primary/40 bg-primary/10 text-white font-semibold flex items-center justify-center gap-2 hover:bg-primary/20 transition-all"
            data-testid="btn-try-now"
          >
            <Shirt className="w-5 h-5 text-primary" />
            Virtual Try-On
          </button>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <button
            onClick={handleAddToCart}
            className={cn(
              "flex-1 py-4 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-[0.98]",
              addedToCart
                ? "bg-green-500/20 border border-green-500/40 text-green-400"
                : "bg-white/10 border border-white/10 hover:bg-white/20 text-white"
            )}
            data-testid="btn-add-to-cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {addedToCart ? "Added!" : "Add to Cart"}
          </button>
          <button
            className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#FF512F] to-[#DD2476] text-white font-bold text-base hover:shadow-[0_0_25px_rgba(221,36,118,0.5)] transition-all active:scale-[0.98]"
            data-testid="btn-buy-now"
          >
            Buy Now
          </button>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div className="mt-4">
            <h2 className="text-lg font-bold mb-3">You may also like</h2>
            <div className="grid grid-cols-2 gap-3">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Virtual Try-On Modal */}
      <AnimatePresence>
        {tryOnOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-xl flex flex-col"
            data-testid="try-on-modal"
          >
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h2 className="font-bold text-lg">Virtual Try-On</h2>
              <button
                onClick={() => { setTryOnOpen(false); setTryOnImage(null); }}
                className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                data-testid="btn-close-try-on"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {!tryOnImage ? (
                <div className="flex flex-col gap-4 mt-4">
                  <p className="text-white/50 text-sm text-center">Choose how you'd like to try on this item</p>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="glass-card rounded-2xl p-6 flex flex-col items-center gap-3 hover:bg-white/10 transition-colors"
                    data-testid="btn-upload-photo"
                  >
                    <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#FF512F]/20 to-[#DD2476]/20 flex items-center justify-center">
                      <Upload className="w-7 h-7 text-primary" />
                    </div>
                    <div className="text-center">
                      <div className="font-semibold">Upload Photo</div>
                      <div className="text-xs text-white/40 mt-1">Choose a photo from your device</div>
                    </div>
                  </button>
                  <button
                    className="glass-card rounded-2xl p-6 flex flex-col items-center gap-3 hover:bg-white/10 transition-colors"
                    data-testid="btn-open-camera"
                  >
                    <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-blue-500/20 to-violet-500/20 flex items-center justify-center">
                      <Camera className="w-7 h-7 text-blue-400" />
                    </div>
                    <div className="text-center">
                      <div className="font-semibold">Open Camera</div>
                      <div className="text-xs text-white/40 mt-1">Take a photo in real-time</div>
                    </div>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                    data-testid="input-photo-upload"
                  />
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center gap-4 mt-4"
                >
                  <div className="relative w-full max-w-sm aspect-[3/4] rounded-3xl overflow-hidden mx-auto">
                    <img src={tryOnImage} alt="Your photo" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-3/4 h-3/4 object-contain opacity-70 mix-blend-multiply"
                        style={{ filter: "drop-shadow(0 0 24px rgba(221,36,118,0.5))" }}
                      />
                    </div>
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                      <div className="text-xs text-white/60 text-center">Virtual try-on preview</div>
                    </div>
                  </div>
                  <button
                    onClick={() => setTryOnImage(null)}
                    className="text-sm text-white/50 underline"
                    data-testid="btn-retake-photo"
                  >
                    Try a different photo
                  </button>
                  <button
                    onClick={handleAddToCart}
                    className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#FF512F] to-[#DD2476] font-bold text-base"
                    data-testid="btn-try-on-add-cart"
                  >
                    Add to Cart
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
